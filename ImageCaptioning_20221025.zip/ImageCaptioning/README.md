# 图像字幕大师
本项目会通过keras搭建一个深度卷积神经网络来为图片生成一行字幕
## 最终结果
![result](/result.jpg)
## 网络架构
![Network](/image_caption.png)
## 数据集
MS COCO dataset:http://cocodataset.org/
## 运行环境
python 3.7
keras版本2.3
tensorflow版本1.14
